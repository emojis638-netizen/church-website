const express = require('express');
const cors = require('cors');
const compression = require('compression');
const path = require('path');

const authRoutes = require('./routes/auth');
const pagesRoutes = require('./routes/pages');
const newsRoutes = require('./routes/news');
const uploadRoutes = require('./routes/upload');

const app = express();
const PORT = Number(process.env.PORT) || 4000;
const HOST = process.env.HOST || '0.0.0.0';

app.disable('x-powered-by');
app.use(cors());
app.use(compression());
app.use(express.json({ limit: '2mb' }));

// Lightweight health check for hosting platforms.
app.get('/health', (req, res) => {
  res.status(200).json({ ok: true });
});

// Uploaded images.
// On Render, set UPLOAD_DIR to the persistent disk location.
const uploadDir = process.env.UPLOAD_DIR || path.join(__dirname, 'uploads');
app.use('/uploads', express.static(uploadDir, {
  maxAge: '7d',
  etag: true,
  setHeaders: (res) => {
    res.setHeader('Cache-Control', 'public, max-age=604800');
  },
}));

// API routes
app.use('/api/auth', authRoutes);
app.use('/api/pages', pagesRoutes);
app.use('/api/news', newsRoutes);
app.use('/api/upload', uploadRoutes);

const frontendDir = path.join(__dirname, '..', 'frontend');
const staticOptions = {
  etag: true,
  setHeaders: (res, filePath) => {
    const ext = path.extname(filePath).toLowerCase();
    const isAsset = ['.css', '.js', '.jpg', '.jpeg', '.png', '.gif', '.webp', '.svg', '.ico', '.woff', '.woff2'].includes(ext);
    if (isAsset) {
      res.setHeader('Cache-Control', 'public, max-age=604800');
    } else {
      // HTML should revalidate so site updates appear without a hard refresh.
      res.setHeader('Cache-Control', 'no-cache');
    }
  },
};

// Serve the public frontend and admin dashboard.
app.use('/', express.static(frontendDir, staticOptions));
app.use('/admin', express.static(path.join(frontendDir, 'admin'), staticOptions));

// Fallback 404 for unknown API routes
app.use('/api', (req, res) => res.status(404).json({ error: 'Not found.' }));

app.listen(PORT, HOST, () => {
  console.log(`\n  Church website server running on http://${HOST}:${PORT}`);
  console.log(`  Public site: http://localhost:${PORT}`);
  console.log(`  Admin login: http://localhost:${PORT}/admin/login.html\n`);
});
