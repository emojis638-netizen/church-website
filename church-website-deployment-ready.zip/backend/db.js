// JSON-file database. In production, DB_PATH can point at persistent storage.
const fs = require('fs');
const path = require('path');

const DEFAULT_DB_PATH = path.join(__dirname, 'data', 'db.json');
const DB_PATH = process.env.DB_PATH || DEFAULT_DB_PATH;

function ensureDatabase() {
  const dir = path.dirname(DB_PATH);
  if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });

  // If production persistent storage is empty on first boot, seed it from the
  // database shipped with the project. Never overwrite an existing database.
  if (!fs.existsSync(DB_PATH) && DB_PATH !== DEFAULT_DB_PATH && fs.existsSync(DEFAULT_DB_PATH)) {
    fs.copyFileSync(DEFAULT_DB_PATH, DB_PATH);
  }
}

function load() {
  ensureDatabase();
  const raw = fs.readFileSync(DB_PATH, 'utf-8');
  return JSON.parse(raw);
}

function save(data) {
  ensureDatabase();
  const tmpPath = `${DB_PATH}.tmp`;
  fs.writeFileSync(tmpPath, JSON.stringify(data, null, 2), 'utf-8');
  fs.renameSync(tmpPath, DB_PATH);
}

function nextId(data, kind) {
  const id = data.nextIds[kind] || 1;
  data.nextIds[kind] = id + 1;
  return id;
}

module.exports = { load, save, nextId };
